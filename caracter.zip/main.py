print ("Cristian David Salas De La O 3-W") #Esta linea define el nombre del programdor 
def es_vocal(caracter): #Esta linea define la funcion 

    vocales = 'aeiouAEIOU' #Esta linea define la vocales
    return caracter in vocales #Esta linea concluye la funcion 

caracter = input("Ingrese un carácter: ") #Esta linea solicita el caracter

if len(caracter) == 1: #Esta linea define el caracter

    if es_vocal(caracter): #Esta linea define el if de la vocal
        print("Es una vocal.") #Esta linea muestra que es una vocal
    else: #Esta linea dice que hacer si no se cumpla las peticiones 
        print("No es una vocal.") #Esta linea meustra que no es una vocal
else: #Esta linea muestra que hacer si no se cumplen con las peticiones 
    print("Por favor, ingrese solo un carácter.") #Esta linea muestra que no es solo un caracter
