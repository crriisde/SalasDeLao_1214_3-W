print ("Cristian David Salas De La o 3-W") #Esta linea define el nombre del programador
def saludar(nombre): #esta linea define la funcion 
    return f"¡Hola {nombre}!" #esta linea concluye la funcion

nombre = input("Introduce tu nombre: ") #esta linea solicita que el usuario ingrese su nombre 

print(saludar(nombre)) #Esta linea muestra el saludo y tu nombre
