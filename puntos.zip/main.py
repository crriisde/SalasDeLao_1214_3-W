print ("Cristian David Salas De la o 3.W") #Esta linea define el nombre del programdor 
import math  #Esta linea genera mas funciones matematicas

def distancia_dirigida(punto1, punto2):  #Esta linea define la funcion 

    x1, y1 = punto1  #Esta linea define la distacia del punto
    x2, y2 = punto2  #Esta linea define la distancia del segundo punto 
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)  #Esta linea conclutye la funcion 

x1 = float(input("Ingrese la coordenada x del primer punto: "))  #Esta linea solicita la ingrecio de la cordenada 
y1 = float(input("Ingrese la coordenada y del primer punto: ")) #Esta linea solicita la ingrecio de la cordenada 
x2 = float(input("Ingrese la coordenada x del segundo punto: ")) #Esta linea solicita la ingrecio de la cordenada 
y2 = float(input("Ingrese la coordenada y del segundo punto: ")) #Esta linea solicita la ingrecio de la cordenada 

punto1 = (x1, y1) #Esta linea define la cordenada del punto 1 
punto2 = (x2, y2) #Esta linea define la cordeanada del putno 2

distancia = distancia_dirigida(punto1, punto2) #Esta linea define la distancia 

print(f"La distancia dirigida entre los puntos {punto1} y {punto2} es: {distancia:.2f}") #Esta linea muestra el resultado 
