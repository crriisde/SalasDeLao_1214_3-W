def sum(numbers): #esta linea define la funcion 
    total = 0 #esta linea define el total 
    for number in numbers: #esta linea pone el valor de numeros 
        total += number #esta linea define el total 
    return total #esta linea concluye parte de la funcion 

def multip(numbers): #esta linea define la funcion 
    product = 1#esta linea define el producto 
    for number in numbers: #esta linea pone el valor de los numeros 
        product *= number #esta linea define el producto 
    return product #esta linea concluye parte de la funcion 

input_values = input("Ingrese los numeros separados por comas: ") #esta linea solicita los numeros
numbers = [int(x) for x in input_values.split(',')] #esta linea procesa los valores

print("La suma es:", sum(numbers)) #esta linea muestra el resultado 
print("El producto es:", multip(numbers)) #esta linea muestra el resultado 