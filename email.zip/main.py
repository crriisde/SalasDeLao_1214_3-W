print ("Cristian David Salas De La O 3-W") #Esta linea define el nombre del programador
def es_email_valido(email): #Esta linea define la funcion 

    return '@' in email #Esta linea concluye la funcion 

email = input("Ingrese una direccion de email: ") #Esta linea solicita el email

if es_email_valido(email): #Esta linea sala el proceso de el resultado
    print("La direccion de email es valida.") #Esta linea muestra que se cumple la peticion 
else: #Esta linea  define que hacer si no se cumple la condiccion
    print("La direccion de email no es valida.") #Esta linea  avisa que no es correcto el email
