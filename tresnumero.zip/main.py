print ("Cristian David Salas De La O 3-W") #Esta linea define el nombre del programador 
def mayor_de_tres(): #Esta linea define la funcion 
    num1 = float(input("Ingresa el primer numero: ")) #Esta linea solicita el primer numero 
    num2 = float(input("Ingresa el segundo numero: "))#Esta linea solicita el segundo numero 
    num3 = float(input("Ingresa el tercer numero: ")) #Esta linea solicita el tercer numero 
    return max(num1, num2, num3) #Esta linea cocluye parte de la funcion 

resultado = mayor_de_tres() #Esta linea define el resultadoo
print("El mayor de los tres numeros es:", resultado) #Esta linea muestra el resultado 


