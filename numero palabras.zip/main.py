print ("Cristian David Salas De La O 3-W") #Esta linea define el nombre del programador 
def ultima_palabra(s): #Esta linea define la funcion

    palabras = s.strip().split() #Esta linea define como saber cuantas palabras teine 

    if palabras: #Esta linea dice que hacer 
        return len(palabras[-1])
    return 0

texto = input("Ingresa un texto ")
print("La longitud de la ultima palabra es:", ultima_palabra(texto))

