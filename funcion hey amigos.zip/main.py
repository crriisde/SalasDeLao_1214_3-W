print ("Cristian David Salas De La O 3'W") #Esta linea muestra el nombre del progrmador
def saludo(): #Esta linea define la funcion del saludo
    print("Hey amigos!") #Esta linea define lo que se va mostrar de la funcion 

for _ in range(5): #Esta funcion define cuantas veces se mostrara la funcion, esto se puede cambiar
    saludo() #Esta linea define el final de la funcion
