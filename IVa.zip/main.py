print ("Cristian David Salas De La O 3-W") #Esta linea define le nombre del programador
def calcular_total_factura(cantidad_sin_iva, porcentaje_iva): #Esta linea define la funcion 
    iva = cantidad_sin_iva * (porcentaje_iva / 100) #Esta linea define como sacar el iva
    total = cantidad_sin_iva + iva #Esta linea define el total 
    return total #Esta linea cocluye la funcion 

cantidad_sin_iva = float(input("Ingrese la cantidad sin IVA: ")) #Esta linea solicita la cantidad sin iva
porcentaje_iva = float(input("Ingrese el porcentaje de IVA: ")) #Esta linea solicita el porcentaje del iva

total_factura = calcular_total_factura(cantidad_sin_iva, porcentaje_iva) #Esta linea muestra el total de la factura

print(f"El total de la factura incluyendo IVA, es: {total_factura:.2f}") #Esta linea muestra el resultado 
